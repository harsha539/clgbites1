// Seeds the 4 real restaurants + their menus.
// Run once with: npm run seed
// Safe to re-run after deleting data/clgbites.db to start fresh.
require("dotenv").config();
const db = require("./db");

const insertRestaurant = db.prepare(`
  INSERT INTO restaurants (name, description, image_url, whatsapp_number, is_active)
  VALUES (?, ?, ?, ?, 1)
`);
const insertItem = db.prepare(`
  INSERT INTO menu_items (restaurant_id, name, description, price, is_active)
  VALUES (?, ?, ?, ?, 1)
`);

const existing = db.prepare("SELECT COUNT(*) AS c FROM restaurants").get().c;
if (existing > 0) {
  console.log("Restaurants already exist, skipping seed. Delete data/clgbites.db first if you want to reseed.");
  process.exit(0);
}

// NOTE: all 4 menu cards list the same number, 7842960252 (India, +91).
// If that's wrong for any of them, just edit the whatsapp_number strings below
// (or fix it later from the admin panel).
const WA = "917842960252";

// ---------------- 1. A1 Biryani Point ----------------
const r1 = insertRestaurant.run(
  "A1 Biryani Point",
  "Taste that stays with you. Hot. Fresh. Delicious.",
  "",
  WA
).lastInsertRowid;

[
  ["Dum Biryani", "", 180],
  ["Fry Biryani", "", 200],
  ["Mixed Biryani", "", 210],
].forEach(([name, desc, price]) => insertItem.run(r1, name, desc, price));

// ---------------- 2. The Food Corner ----------------
const r2 = insertRestaurant.run(
  "The Food Corner",
  "Fresh & Tasty. Please order before 5pm.",
  "",
  WA
).lastInsertRowid;

[
  // Noodles
  ["Veg Noodles", "Noodles", 90],
  ["Veg Manchurian Noodles", "Noodles", 100],
  ["Veg Paneer Noodles", "Noodles", 120],
  ["Egg Noodles", "Noodles", 100],
  ["Double Egg Noodles", "Noodles", 110],
  ["Egg Manchurian Noodles", "Noodles", 110],
  ["Egg Paneer Noodles", "Noodles", 130],
  ["Chicken Noodles", "Noodles", 120],
  ["Double Egg Chicken Noodles", "Noodles", 130],
  // Fried Rice
  ["Veg Fried Rice", "Fried Rice", 90],
  ["Veg Manchurian Fried Rice", "Fried Rice", 100],
  ["Veg Paneer Fried Rice", "Fried Rice", 120],
  ["Egg Paneer Fried Rice", "Fried Rice", 130],
  ["Egg Fried Rice", "Fried Rice", 100],
  ["Double Egg Fried Rice", "Fried Rice", 110],
  ["Egg Manchurian Fried Rice", "Fried Rice", 100],
  ["Chicken Fried Rice", "Fried Rice", 120],
  ["Double Egg Chicken Fried Rice", "Fried Rice", 130],
  // Manchurian
  ["Veg Manchurian", "Manchurian", 90],
  ["Egg Manchurian", "Manchurian", 100],
  ["Double Egg Manchurian", "Manchurian", 110],
  // Starters / Plate
  ["Chicken Manchurian", "Starters", 180],
  ["Chicken Chilli", "Starters", 180],
  ["4P Chicken Lollipop", "Plate", 160],
].forEach(([name, desc, price]) => insertItem.run(r2, name, desc, price));

// ---------------- 3. Bhimasena ----------------
const r3 = insertRestaurant.run(
  "Bhimasena",
  "Biryani | Starters | Curries | More — Bold Flavors. Royal Experience.",
  "",
  WA
).lastInsertRowid;

[
  // Veg Starters
  ["Veg Manchuria", "Veg Starters", 210],
  ["Chilli Mushroom", "Veg Starters", 230],
  ["Crispy Baby Corn", "Veg Starters", 230],
  ["Paneer 65", "Veg Starters", 280],
  ["Paneer Majestic", "Veg Starters", 290],
  // Non-Veg Starters
  ["Chilli Chicken", "Non-Veg Starters", 290],
  ["Chicken Manchuria", "Non-Veg Starters", 290],
  ["Chicken 65", "Non-Veg Starters", 290],
  ["Chicken Majestic", "Non-Veg Starters", 290],
  // Veg Biryani
  ["Special Paneer Biryani", "Veg Biryani", 290],
  ["Special Mushroom Biryani", "Veg Biryani", 290],
  ["Special Veg Biryani", "Veg Biryani", 260],
  ["Ulavacharu Biryani", "Veg Biryani", 270],
  ["Kaju Biryani", "Veg Biryani", 290],
  ["Special Kaju Biryani", "Veg Biryani", 310],
  // Non-Veg Biryani
  ["Special Egg Biryani", "Non-Veg Biryani", 280],
  ["Chicken Dum Biryani", "Non-Veg Biryani", 270],
  ["Kundan Biryani", "Non-Veg Biryani", 360],
  ["Chicken Fry Biryani", "Non-Veg Biryani", 280],
  ["Special Chicken Biryani", "Non-Veg Biryani", 300],
  ["Joint Biryani", "Non-Veg Biryani", 310],
  ["Chicken Mughlai Biryani", "Non-Veg Biryani", 310],
  ["Chicken Lollipop Biryani", "Non-Veg Biryani", 330],
  ["Gongura Chicken Fry Biryani", "Non-Veg Biryani — available only on Thursday", 320],
  // Single Biryani
  ["Single Dum Biryani", "Single Biryani", 180],
  ["Single Fry Biryani", "Single Biryani", 190],
  ["Single Special Biryani", "Single Biryani", 220],
  ["Single Paneer Biryani", "Single Biryani", 200],
  ["Single Mushroom Biryani", "Single Biryani", 200],
  ["Single Mughlai Biryani", "Single Biryani", 220],
  ["Single Gongura Biryani", "Single Biryani — available only on Thursday", 230],
  // Breads
  ["Butter Nan", "Breads", 45],
  ["Roti", "Breads", 25],
  // Veg Curries
  ["Paneer Butter Masala", "Veg Curries", 280],
  ["Kaju Paneer Butter Masala", "Veg Curries", 300],
  // Non-Veg Curries
  ["Egg Burji", "Non-Veg Curries", 190],
  ["Butter Chicken", "Non-Veg Curries", 290],
  ["Chicken Curry", "Non-Veg Curries", 270],
].forEach(([name, desc, price]) => insertItem.run(r3, name, desc, price));

// ---------------- 4. Sindhu Biryani Point ----------------
const r4 = insertRestaurant.run(
  "Sindhu Biryani Point",
  "AC Restaurant — Taste Excellence",
  "",
  WA
).lastInsertRowid;

[
  // Non Veg Starters
  ["Chicken 65", "Non Veg Starters", 210],
  ["Chilli Chicken", "Non Veg Starters", 210],
  ["Chicken Manchurian", "Non Veg Starters", 210],
  // Fried Rice
  ["Kaju Fried Rice", "Fried Rice", 160],
  ["Jeera Rice", "Fried Rice", 160],
  ["Chicken Fried Rice", "Fried Rice", 160],
  ["Egg Fried Rice", "Fried Rice", 140],
  // Biryani's
  ["Joint Biryani", "Biryani", 160],
  ["Wings Biryani", "Biryani", 210],
  ["Lollipop Biryani", "Biryani", 210],
  ["DM Biryani", "Biryani", 190],
  ["Fry Biryani", "Biryani", 200],
  ["Mixed Biryani", "Biryani", 210],
  ["Mini DM Biryani", "Biryani — only dining", 140],
  ["Mini Fry Biryani", "Biryani — only dining", 150],
  ["Bucket DM Biryani", "Biryani", 610],
  ["Bucket Fry Biryani", "Biryani", 710],
  ["Chicken Mughlai Biryani", "Biryani", 240],
].forEach(([name, desc, price]) => insertItem.run(r4, name, desc, price));

console.log("Seeded 4 restaurants with their full menus: A1 Biryani Point, The Food Corner, Bhimasena, Sindhu Biryani Point.");
