require("dotenv").config();
const path = require("path");
const express = require("express");
const session = require("express-session");

require("./db"); // ensures db + tables + admin seed are ready

const authRoutes = require("./routes/auth");
const restaurantRoutes = require("./routes/restaurants");
const orderRoutes = require("./routes/orders");
const adminRoutes = require("./routes/admin");

const app = express();

app.use(express.json());
app.use(
  session({
    secret: process.env.SESSION_SECRET || "dev_secret_change_me",
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      maxAge: 1000 * 60 * 60 * 24 * 7, // 7 days
    },
  })
);

// API routes
app.use("/api", authRoutes);
app.use("/api", restaurantRoutes);
app.use("/api", orderRoutes);
app.use("/api", adminRoutes);

// Frontend static files
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Clg Bites running at http://localhost:${PORT}`);
});
