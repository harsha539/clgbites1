# Clg Bites

A simple food-ordering website for a college campus:
- Students sign up / log in
- Browse restaurants and menus (only ones the admin has switched **on** are shown)
- Add items to cart and place an order
- Placing an order opens **WhatsApp** with a pre-filled message to that restaurant's number — the restaurant just hits send to confirm they've seen it
- An **admin panel** (`/admin.html`) lets you turn restaurants on/off, turn individual menu items on/off, add new restaurants/items, and see all orders

Tech used: Node.js + Express (backend/API), SQLite via `better-sqlite3` (database, a single file — no separate DB server to install), vanilla HTML/CSS/JS (frontend, no build step needed).

---

## 1. Install and run locally

You need [Node.js](https://nodejs.org) (v18 or newer) installed.

```bash
cd clg-bites
npm install
cp .env.example .env
```

Open `.env` and set:
- `SESSION_SECRET` — any long random string
- `ADMIN_USERNAME` / `ADMIN_PASSWORD` — your admin login (only used the very first time the app starts, to create the admin account)

Then start the server:

```bash
npm start
```

Visit:
- `http://localhost:3000` — the student-facing site
- `http://localhost:3000/admin.html` — the admin panel

Run `npm run seed` once to load your 4 real restaurants and their full menus (A1 Biryani Point, The Food Corner, Bhimasena, Sindhu Biryani Point) — taken straight from the menu cards. All 4 currently point to the same WhatsApp number, `917842960252`, since that's what was on all four cards; if that's wrong for any of them, fix the number from the admin panel or by editing `init-db.js` before seeding.

The database is a single file at `data/clgbites.db`, created automatically the first time you run the app. Delete it any time to start fresh.

---

## 2. How the WhatsApp part works (important)

This app does **not** use the paid WhatsApp Business API (that requires Meta Business verification and approval, which is overkill for a college project). Instead it uses WhatsApp's free `wa.me` click-to-chat links:

```
https://wa.me/<restaurant_whatsapp_number>?text=<pre-filled order message>
```

When a student places an order:
1. The order is saved in the database.
2. The server builds a WhatsApp link containing the restaurant name, items, quantities, total, the student's name/phone, and any delivery note.
3. The browser opens that link in a new tab, which opens WhatsApp (app or web) with the message already typed into a chat with the restaurant's number.
4. The student (or the site, if you set it up as auto-redirect) just needs to hit **Send**.

**Requirements for this to work:**
- Each restaurant needs a real WhatsApp number saved in the admin panel, in the format: country code + number, digits only, no `+`, no spaces (e.g. an Indian number `9876543210` becomes `919876543210`).
- Whoever opens the link needs WhatsApp installed (mobile) or WhatsApp Web logged in (desktop) — this will normally be the student placing the order, and they're sending it to the restaurant's number.

**If you'd rather orders land directly in the restaurant's WhatsApp without the student manually pressing send** (i.e. fully automatic), that requires the real WhatsApp Business Platform API, which needs:
- A Meta Business account + business verification
- A registered WhatsApp Business phone number
- Either Meta's Cloud API directly, or a provider like Twilio/Gupshup/360dialog on top of it
- Backend code to call their `/messages` endpoint instead of building a `wa.me` link

That's a bigger project — happy to help you build that version too if you want it later; the `wa.me` approach is the fastest way to get something working for free right now.

---

## 3. Project structure

```
clg-bites/
  server.js              # Express app entry point
  db.js                  # SQLite connection + schema + admin seeding
  init-db.js             # seeds the 4 real restaurants + menus (npm run seed)
  routes/
    auth.js               # student signup/login/logout
    restaurants.js         # public restaurant + menu browsing (active only)
    orders.js               # place order -> builds WhatsApp link
    admin.js                 # admin login + restaurant/menu toggles + order list
  middleware/auth.js      # requireLogin / requireAdmin guards
  public/                 # everything the browser loads
    index.html             # restaurant listing (home page)
    login.html / signup.html
    restaurant.html          # menu + cart + WhatsApp checkout
    orders.html               # a student's own order history
    admin.html                 # admin dashboard shell
    js/main.js                  # shared fetch helper
    js/admin.js                  # admin dashboard logic
    css/style.css                 # all styling
```

---

## 4. Putting it online (so students can actually use it from their phones)

**Recommended: Render.com** — free tier, simplest setup for a Node.js app like this. Step by step:

1. **Put the code on GitHub** (Render deploys from a git repo):
   - Create a new repository on [github.com](https://github.com) (e.g. `clg-bites`)
   - In the unzipped project folder, run:
     ```bash
     git init
     git add .
     git commit -m "Initial commit"
     git branch -M main
     git remote add origin https://github.com/<your-username>/clg-bites.git
     git push -u origin main
     ```
     (`.env` and `data/*.db` won't be pushed — they're in `.gitignore` on purpose, since they contain secrets/local data.)

2. **Create the web service on Render**:
   - Go to [render.com](https://render.com) → sign up/log in → **New +** → **Web Service**
   - Connect your GitHub account and pick the `clg-bites` repo
   - Settings:
     - **Runtime**: Node
     - **Build Command**: `npm install`
     - **Start Command**: `npm start`
     - **Instance type**: Free
   - Under **Environment**, add these environment variables (same names as `.env.example`):
     - `SESSION_SECRET` → any long random string
     - `ADMIN_USERNAME` → your admin login name
     - `ADMIN_PASSWORD` → your admin login password
   - Click **Create Web Service**. Render will build and deploy — you'll get a live URL like `https://clg-bites.onrender.com`.

3. **Load your real restaurants**: Render gives you a **Shell** tab on the service dashboard — open it and run:
   ```bash
   npm run seed
   ```
   This loads A1 Biryani Point, The Food Corner, Bhimasena, and Sindhu Biryani Point with their full menus (see section 2 below).

4. **One important limitation on Render's free tier**: the filesystem resets on every redeploy (e.g. when you push new code), which wipes the SQLite database — including new signups and orders, not just your seed data. That's fine while you're building/testing. Before you rely on it for real ongoing use, either:
   - Attach a Render **persistent disk** (small paid add-on, keeps `data/` between deploys), or
   - Move to a hosted database like Postgres instead of the local SQLite file — ask me and I'll convert the project for you.

**Alternatives**, same general steps as above (GitHub repo → connect → set env vars → deploy):
- **Railway.app** — similar free tier, also very simple
- **Fly.io** — free tier, a bit more config but has proper persistent volumes
- **Your own VPS / college server** — install Node.js, `git clone` (or copy) the folder, `npm install && npm start`, keep it running with a process manager like `pm2`, and put it behind Nginx with a free HTTPS certificate (Certbot/Let's Encrypt). No filesystem-reset problem here since it's your own disk.

---

## 5. Security notes before you use this for real

- Change `ADMIN_PASSWORD` and `SESSION_SECRET` in `.env` — never commit `.env` to GitHub (a `.gitignore` is included).
- Passwords are hashed with bcrypt, sessions are HTTP-only cookies — reasonable for a small project, but if this handles real payments later you'd want to add HTTPS (required in production), rate-limiting on login, and probably a proper database.
- This build does **not** handle online payments — it assumes cash on delivery / pay the restaurant directly, since the order is just a WhatsApp message. Ask me if you want a Razorpay/Stripe payment step added.
