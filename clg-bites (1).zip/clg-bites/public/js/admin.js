let currentTab = 'restaurants';
let restaurantsCache = [];

async function init() {
  const me = await api('/api/admin/me');
  document.getElementById('nav').innerHTML = me.isAdmin
    ? `<span>Hi, ${me.username}</span> <button class="btn secondary small" onclick="adminLogout()">Log out</button>`
    : '';
  if (me.isAdmin) {
    renderDashboard();
  } else {
    renderLogin();
  }
}

function renderLogin() {
  document.getElementById('app').innerHTML = `
    <form class="auth-form card" id="adminLoginForm">
      <h2>Admin log in</h2>
      <div id="err"></div>
      <label>Username</label>
      <input type="text" id="username" required />
      <label>Password</label>
      <input type="password" id="password" required />
      <button class="btn" type="submit" style="width:100%">Log in</button>
    </form>
  `;
  document.getElementById('adminLoginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    document.getElementById('err').innerHTML = '';
    try {
      await api('/api/admin/login', 'POST', {
        username: document.getElementById('username').value,
        password: document.getElementById('password').value,
      });
      init();
    } catch (err) {
      document.getElementById('err').innerHTML = `<div class="error-msg">${err.message}</div>`;
    }
  });
}

async function adminLogout() {
  await api('/api/admin/logout', 'POST');
  init();
}

function renderDashboard() {
  document.getElementById('app').innerHTML = `
    <div class="tabs">
      <div class="tab ${currentTab === 'restaurants' ? 'active' : ''}" onclick="switchTab('restaurants')">Restaurants</div>
      <div class="tab ${currentTab === 'menu' ? 'active' : ''}" onclick="switchTab('menu')">Menu Items</div>
      <div class="tab ${currentTab === 'orders' ? 'active' : ''}" onclick="switchTab('orders')">Orders</div>
    </div>
    <div id="tabContent"></div>
  `;
  if (currentTab === 'restaurants') renderRestaurantsTab();
  if (currentTab === 'menu') renderMenuTab();
  if (currentTab === 'orders') renderOrdersTab();
}

function switchTab(tab) {
  currentTab = tab;
  renderDashboard();
}

// ---------------- Restaurants tab ----------------
async function renderRestaurantsTab() {
  const el = document.getElementById('tabContent');
  const restaurants = await api('/api/admin/restaurants');
  restaurantsCache = restaurants;

  el.innerHTML = `
    <div class="section-title"><h3>Restaurants</h3></div>
    <div class="card">
      <table class="admin-table">
        <thead><tr><th>Name</th><th>WhatsApp #</th><th>Active</th><th></th></tr></thead>
        <tbody>
          ${restaurants.map(r => `
            <tr>
              <td>${r.name}</td>
              <td>${r.whatsapp_number}</td>
              <td>
                <label class="switch">
                  <input type="checkbox" ${r.is_active ? 'checked' : ''} onchange="toggleRestaurant(${r.id}, this.checked)" />
                  <span class="slider"></span>
                </label>
              </td>
              <td><button class="btn ghost small" onclick="deleteRestaurant(${r.id})">Delete</button></td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>

    <div class="section-title"><h3>Add restaurant</h3></div>
    <form class="card" id="addRestaurantForm" style="display:grid;gap:10px;max-width:480px">
      <input placeholder="Restaurant name" id="rName" required style="padding:10px;border-radius:8px;border:1.5px solid var(--border)" />
      <input placeholder="Description" id="rDesc" style="padding:10px;border-radius:8px;border:1.5px solid var(--border)" />
      <input placeholder="WhatsApp number incl. country code, digits only (e.g. 919876543210)" id="rWhatsapp" required style="padding:10px;border-radius:8px;border:1.5px solid var(--border)" />
      <button class="btn" type="submit">Add restaurant</button>
    </form>
  `;

  document.getElementById('addRestaurantForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await api('/api/admin/restaurants', 'POST', {
        name: document.getElementById('rName').value,
        description: document.getElementById('rDesc').value,
        whatsapp_number: document.getElementById('rWhatsapp').value,
      });
      renderRestaurantsTab();
    } catch (err) { alert(err.message); }
  });
}

async function toggleRestaurant(id, isActive) {
  await api(`/api/admin/restaurants/${id}`, 'PATCH', { is_active: isActive ? 1 : 0 });
}

async function deleteRestaurant(id) {
  if (!confirm('Delete this restaurant and all its menu items?')) return;
  await api(`/api/admin/restaurants/${id}`, 'DELETE');
  renderRestaurantsTab();
}

// ---------------- Menu items tab ----------------
async function renderMenuTab() {
  const el = document.getElementById('tabContent');
  if (restaurantsCache.length === 0) {
    restaurantsCache = await api('/api/admin/restaurants');
  }
  if (restaurantsCache.length === 0) {
    el.innerHTML = `<p class="muted">Add a restaurant first, then come back here to add menu items.</p>`;
    return;
  }

  el.innerHTML = `
    <div class="section-title">
      <h3>Menu items</h3>
      <select id="restaurantSelect" style="padding:8px;border-radius:8px;border:1.5px solid var(--border)">
        ${restaurantsCache.map(r => `<option value="${r.id}">${r.name}</option>`).join('')}
      </select>
    </div>
    <div class="card" id="menuItemsList"></div>

    <div class="section-title"><h3>Add menu item</h3></div>
    <form class="card" id="addItemForm" style="display:grid;gap:10px;max-width:480px">
      <input placeholder="Item name" id="iName" required style="padding:10px;border-radius:8px;border:1.5px solid var(--border)" />
      <input placeholder="Description" id="iDesc" style="padding:10px;border-radius:8px;border:1.5px solid var(--border)" />
      <input placeholder="Price (₹)" id="iPrice" type="number" step="0.01" required style="padding:10px;border-radius:8px;border:1.5px solid var(--border)" />
      <button class="btn" type="submit">Add item</button>
    </form>
  `;

  const select = document.getElementById('restaurantSelect');
  select.addEventListener('change', () => loadMenuItems(select.value));
  loadMenuItems(select.value);

  document.getElementById('addItemForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    try {
      await api('/api/admin/menu-items', 'POST', {
        restaurant_id: Number(select.value),
        name: document.getElementById('iName').value,
        description: document.getElementById('iDesc').value,
        price: document.getElementById('iPrice').value,
      });
      loadMenuItems(select.value);
      document.getElementById('addItemForm').reset();
    } catch (err) { alert(err.message); }
  });
}

async function loadMenuItems(restaurantId) {
  const items = await api(`/api/admin/menu-items?restaurant_id=${restaurantId}`);
  const list = document.getElementById('menuItemsList');
  if (!items.length) {
    list.innerHTML = `<p class="muted">No menu items yet for this restaurant.</p>`;
    return;
  }
  list.innerHTML = `
    <table class="admin-table">
      <thead><tr><th>Name</th><th>Price</th><th>Active</th><th></th></tr></thead>
      <tbody>
        ${items.map(i => `
          <tr>
            <td>${i.name}</td>
            <td>₹${i.price}</td>
            <td>
              <label class="switch">
                <input type="checkbox" ${i.is_active ? 'checked' : ''} onchange="toggleItem(${i.id}, this.checked, ${restaurantId})" />
                <span class="slider"></span>
              </label>
            </td>
            <td><button class="btn ghost small" onclick="deleteItem(${i.id}, ${restaurantId})">Delete</button></td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

async function toggleItem(id, isActive) {
  await api(`/api/admin/menu-items/${id}`, 'PATCH', { is_active: isActive ? 1 : 0 });
}

async function deleteItem(id, restaurantId) {
  if (!confirm('Delete this menu item?')) return;
  await api(`/api/admin/menu-items/${id}`, 'DELETE');
  loadMenuItems(restaurantId);
}

// ---------------- Orders tab ----------------
async function renderOrdersTab() {
  const el = document.getElementById('tabContent');
  const orders = await api('/api/admin/orders');
  if (!orders.length) {
    el.innerHTML = `<p class="muted">No orders yet.</p>`;
    return;
  }
  el.innerHTML = orders.map(o => `
    <div class="card" style="margin-top:12px">
      <div style="display:flex;justify-content:space-between">
        <strong>#${o.id} · ${o.restaurant_name}</strong>
        <span class="muted">${new Date(o.created_at).toLocaleString()}</span>
      </div>
      <p class="muted" style="margin:6px 0">${o.items.map(i => `${i.qty}x ${i.name}`).join(', ')}</p>
      <div>Customer: ${o.user_name} (${o.user_phone}) &middot; Total: <strong>₹${o.total}</strong></div>
      ${o.delivery_note ? `<div class="muted">Note: ${o.delivery_note}</div>` : ''}
    </div>
  `).join('');
}

init();
