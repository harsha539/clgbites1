const express = require("express");
const bcrypt = require("bcryptjs");
const db = require("../db");

const router = express.Router();

// ---- Sign up ----
router.post("/signup", (req, res) => {
  const { name, email, phone, password } = req.body;
  if (!name || !email || !phone || !password) {
    return res.status(400).json({ error: "All fields are required." });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: "Password must be at least 6 characters." });
  }

  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email.toLowerCase());
  if (existing) {
    return res.status(400).json({ error: "An account with this email already exists." });
  }

  const hash = bcrypt.hashSync(password, 10);
  const result = db
    .prepare("INSERT INTO users (name, email, phone, password_hash) VALUES (?, ?, ?, ?)")
    .run(name, email.toLowerCase(), phone, hash);

  req.session.userId = result.lastInsertRowid;
  req.session.userName = name;
  res.json({ id: result.lastInsertRowid, name, email, phone });
});

// ---- Log in ----
router.post("/login", (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: "Email and password are required." });
  }

  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email.toLowerCase());
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(400).json({ error: "Invalid email or password." });
  }

  req.session.userId = user.id;
  req.session.userName = user.name;
  res.json({ id: user.id, name: user.name, email: user.email, phone: user.phone });
});

// ---- Log out ----
router.post("/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

// ---- Current user ----
router.get("/me", (req, res) => {
  if (!req.session.userId) return res.json(null);
  const user = db
    .prepare("SELECT id, name, email, phone FROM users WHERE id = ?")
    .get(req.session.userId);
  res.json(user || null);
});

module.exports = router;
