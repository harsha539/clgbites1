const express = require("express");
const db = require("../db");
const { requireLogin } = require("../middleware/auth");

const router = express.Router();

// Place an order -> saves it, returns a wa.me link pre-filled with the order
router.post("/orders", requireLogin, (req, res) => {
  const { restaurant_id, items, delivery_note } = req.body;
  // items = [{ menu_item_id, qty }, ...]

  if (!restaurant_id || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: "Cart is empty." });
  }

  const restaurant = db
    .prepare("SELECT * FROM restaurants WHERE id = ? AND is_active = 1")
    .get(restaurant_id);
  if (!restaurant) {
    return res.status(400).json({ error: "This restaurant is not currently accepting orders." });
  }

  // Re-fetch prices from DB (never trust client-sent prices) and check items are active
  let total = 0;
  const lineItems = [];
  for (const line of items) {
    const item = db
      .prepare("SELECT * FROM menu_items WHERE id = ? AND restaurant_id = ? AND is_active = 1")
      .get(line.menu_item_id, restaurant_id);
    if (!item) continue; // skip items that got disabled/removed
    const qty = Math.max(1, parseInt(line.qty) || 1);
    total += item.price * qty;
    lineItems.push({ name: item.name, price: item.price, qty });
  }

  if (lineItems.length === 0) {
    return res.status(400).json({ error: "None of the items in your cart are available anymore." });
  }

  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.session.userId);

  const orderResult = db
    .prepare(
      "INSERT INTO orders (user_id, restaurant_id, items_json, total, delivery_note) VALUES (?, ?, ?, ?, ?)"
    )
    .run(user.id, restaurant_id, JSON.stringify(lineItems), total, delivery_note || "");

  // Build the WhatsApp message
  const lines = [
    `*New order from Clg Bites* #${orderResult.lastInsertRowid}`,
    `Restaurant: ${restaurant.name}`,
    ``,
    ...lineItems.map((li) => `${li.qty} x ${li.name} - ₹${li.price * li.qty}`),
    ``,
    `Total: ₹${total}`,
    ``,
    `Customer: ${user.name}`,
    `Phone: ${user.phone}`,
    delivery_note ? `Note: ${delivery_note}` : null,
  ].filter(Boolean);

  const message = encodeURIComponent(lines.join("\n"));
  const whatsappUrl = `https://wa.me/${restaurant.whatsapp_number}?text=${message}`;

  res.json({
    order_id: orderResult.lastInsertRowid,
    total,
    whatsapp_url: whatsappUrl,
  });
});

// A logged-in user's own order history
router.get("/orders/mine", requireLogin, (req, res) => {
  const rows = db
    .prepare(
      `SELECT o.id, o.items_json, o.total, o.delivery_note, o.status, o.created_at, r.name AS restaurant_name
       FROM orders o JOIN restaurants r ON r.id = o.restaurant_id
       WHERE o.user_id = ? ORDER BY o.created_at DESC`
    )
    .all(req.session.userId);
  res.json(rows.map((r) => ({ ...r, items: JSON.parse(r.items_json) })));
});

module.exports = router;
