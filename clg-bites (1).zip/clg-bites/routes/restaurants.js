const express = require("express");
const db = require("../db");

const router = express.Router();

// List only ACTIVE restaurants (public)
router.get("/restaurants", (req, res) => {
  const rows = db
    .prepare("SELECT id, name, description, image_url FROM restaurants WHERE is_active = 1 ORDER BY name")
    .all();
  res.json(rows);
});

// Get one restaurant + its ACTIVE menu items only (public)
router.get("/restaurants/:id", (req, res) => {
  const restaurant = db
    .prepare("SELECT id, name, description, image_url FROM restaurants WHERE id = ? AND is_active = 1")
    .get(req.params.id);

  if (!restaurant) {
    return res.status(404).json({ error: "Restaurant not found or currently unavailable." });
  }

  const items = db
    .prepare("SELECT id, name, description, price FROM menu_items WHERE restaurant_id = ? AND is_active = 1 ORDER BY name")
    .all(req.params.id);

  res.json({ ...restaurant, items });
});

module.exports = router;
