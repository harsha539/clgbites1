const express = require("express");
const bcrypt = require("bcryptjs");
const db = require("../db");
const { requireAdmin } = require("../middleware/auth");

const router = express.Router();

// ---- Admin login / logout ----
router.post("/admin/login", (req, res) => {
  const { username, password } = req.body;
  const admin = db.prepare("SELECT * FROM admins WHERE username = ?").get(username);
  if (!admin || !bcrypt.compareSync(password || "", admin.password_hash)) {
    return res.status(400).json({ error: "Invalid admin credentials." });
  }
  req.session.isAdmin = true;
  req.session.adminUsername = admin.username;
  res.json({ ok: true, username: admin.username });
});

router.post("/admin/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

router.get("/admin/me", (req, res) => {
  res.json({ isAdmin: !!req.session.isAdmin, username: req.session.adminUsername || null });
});

// ---- Restaurants (admin sees ALL, active + inactive) ----
router.get("/admin/restaurants", requireAdmin, (req, res) => {
  const rows = db.prepare("SELECT * FROM restaurants ORDER BY name").all();
  res.json(rows);
});

router.post("/admin/restaurants", requireAdmin, (req, res) => {
  const { name, description, image_url, whatsapp_number } = req.body;
  if (!name || !whatsapp_number) {
    return res.status(400).json({ error: "Name and WhatsApp number are required." });
  }
  const result = db
    .prepare(
      "INSERT INTO restaurants (name, description, image_url, whatsapp_number, is_active) VALUES (?, ?, ?, ?, 1)"
    )
    .run(name, description || "", image_url || "", whatsapp_number);
  res.json({ id: result.lastInsertRowid });
});

// Toggle on/off, or edit details
router.patch("/admin/restaurants/:id", requireAdmin, (req, res) => {
  const restaurant = db.prepare("SELECT * FROM restaurants WHERE id = ?").get(req.params.id);
  if (!restaurant) return res.status(404).json({ error: "Restaurant not found." });

  const fields = ["name", "description", "image_url", "whatsapp_number", "is_active"];
  const updates = {};
  for (const f of fields) {
    if (req.body[f] !== undefined) updates[f] = req.body[f];
  }
  const merged = { ...restaurant, ...updates };

  db.prepare(
    `UPDATE restaurants SET name=?, description=?, image_url=?, whatsapp_number=?, is_active=? WHERE id=?`
  ).run(
    merged.name,
    merged.description,
    merged.image_url,
    merged.whatsapp_number,
    merged.is_active ? 1 : 0,
    req.params.id
  );

  res.json({ ok: true });
});

router.delete("/admin/restaurants/:id", requireAdmin, (req, res) => {
  db.prepare("DELETE FROM restaurants WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

// ---- Menu items (admin) ----
router.get("/admin/menu-items", requireAdmin, (req, res) => {
  const { restaurant_id } = req.query;
  const rows = restaurant_id
    ? db.prepare("SELECT * FROM menu_items WHERE restaurant_id = ? ORDER BY name").all(restaurant_id)
    : db.prepare("SELECT * FROM menu_items ORDER BY restaurant_id, name").all();
  res.json(rows);
});

router.post("/admin/menu-items", requireAdmin, (req, res) => {
  const { restaurant_id, name, description, price } = req.body;
  if (!restaurant_id || !name || price === undefined) {
    return res.status(400).json({ error: "Restaurant, name and price are required." });
  }
  const result = db
    .prepare(
      "INSERT INTO menu_items (restaurant_id, name, description, price, is_active) VALUES (?, ?, ?, ?, 1)"
    )
    .run(restaurant_id, name, description || "", parseFloat(price));
  res.json({ id: result.lastInsertRowid });
});

// Toggle on/off, or edit details
router.patch("/admin/menu-items/:id", requireAdmin, (req, res) => {
  const item = db.prepare("SELECT * FROM menu_items WHERE id = ?").get(req.params.id);
  if (!item) return res.status(404).json({ error: "Menu item not found." });

  const fields = ["name", "description", "price", "is_active"];
  const updates = {};
  for (const f of fields) {
    if (req.body[f] !== undefined) updates[f] = req.body[f];
  }
  const merged = { ...item, ...updates };

  db.prepare(`UPDATE menu_items SET name=?, description=?, price=?, is_active=? WHERE id=?`).run(
    merged.name,
    merged.description,
    merged.price,
    merged.is_active ? 1 : 0,
    req.params.id
  );

  res.json({ ok: true });
});

router.delete("/admin/menu-items/:id", requireAdmin, (req, res) => {
  db.prepare("DELETE FROM menu_items WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

// ---- All orders (admin) ----
router.get("/admin/orders", requireAdmin, (req, res) => {
  const rows = db
    .prepare(
      `SELECT o.id, o.items_json, o.total, o.delivery_note, o.status, o.created_at,
              r.name AS restaurant_name, u.name AS user_name, u.phone AS user_phone
       FROM orders o
       JOIN restaurants r ON r.id = o.restaurant_id
       JOIN users u ON u.id = o.user_id
       ORDER BY o.created_at DESC LIMIT 200`
    )
    .all();
  res.json(rows.map((r) => ({ ...r, items: JSON.parse(r.items_json) })));
});

module.exports = router;
